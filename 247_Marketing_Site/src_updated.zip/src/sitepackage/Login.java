package sitepackage;

import org.testng.annotations.Test;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class Login extends BaseClass {

	public String username;
	public String password;
	public String browserType;
	public String getURL;
	public Integer getNumber;
	public String getString;
	public Integer getRandomNumber;
	WebDriver driver;
	public String actualTitle;
	public String expectedTitle = "Beaver Homes and Cottages - Home";

	@Test
	public void homePage() throws InterruptedException, IOException {

		Properties loginProp = loadConfiguration("login.properties");
		Properties configProp = loadConfiguration("config.properties");
		username = loginProp.getProperty("username");
		password = loginProp.getProperty("password");
		browserType = configProp.getProperty("browserType");
		getURL = configProp.getProperty("getURL");

		driver = BaseClass.open(browserType);

		// launch browser and go to the URL
		driver.get(getURL);
		driver.manage().window().maximize();

		// Verify home page title

		actualTitle = driver.getTitle();
		/*
		 * compare the actual title of the page with the expected one and print the
		 * result as "Passed" or "Failed"
		 */
		if (actualTitle.contentEquals(expectedTitle)) {
			System.out.println("Test Title is: " + actualTitle);
		} else {
			System.out.println("Wrong Title Shows!");
		}
		driverWait(1000);
	}
	
	@Test
	public void login() {

		findElementById("lnkTopLoginRequired").click();

		driver.close();
	}

}
